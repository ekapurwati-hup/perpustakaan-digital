-- phpMyAdmin SQL Dump
-- version 4.4.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Feb 04, 2025 at 08:24 AM
-- Server version: 5.6.26
-- PHP Version: 5.6.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `perpustakaan`
--

-- --------------------------------------------------------

--
-- Table structure for table `buku`
--

CREATE TABLE IF NOT EXISTS `buku` (
  `bukuID` int(11) NOT NULL,
  `judul` varchar(255) NOT NULL,
  `penulis` varchar(255) NOT NULL,
  `penerbit` varchar(255) NOT NULL,
  `tahunterbit` year(4) NOT NULL,
  `stok` int(11) NOT NULL,
  `gambar` varchar(255) NOT NULL,
  `keterangan` text NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `buku`
--

INSERT INTO `buku` (`bukuID`, `judul`, `penulis`, `penerbit`, `tahunterbit`, `stok`, `gambar`, `keterangan`) VALUES
(1, 'kamis yang manis', 'John Steinbeck', 'Basabasi', 2019, 8, 'Kamis-yang-Manis.jpg', 'Buku Kamis yang Manis menceritakan kisah Doc, seorang pengusaha yang mengalami tekanan, kesepian, dan kebingungan setelah selesai wajib militer. Doc merasa tertekan karena bisnis spesimen kelautannya, Western Biological, hampir hancur.'),
(2, 'Romeo Juliet', 'William Shakespeare', 'Buku Bijak', 2020, 5, 'Romeo-Juliet.jpg', 'Buku Romeo dan Juliet karya William Shakespeare bercerita tentang kisah cinta tragis dua remaja yang berasal dari keluarga musuh bebuyutan.'),
(3, 'Perempuan Batih', 'A.R. Rizal', 'Laksana', 2018, 6, 'Perempuan-Batih.jpg', 'Buku Perempuan Batih karya A.R. Rizal bercerita tentang perjuangan seorang perempuan bernama Gadis di tengah masyarakat matrilineal Minangkabau, Sumatera Barat. Novel ini mengangkat tema perjuangan perempuan dan kehidupan berat yang harus dihadapi Gadis sebagai anak perempuan satu-satunya.'),
(5, 'Ranselo dan Galang', 'Kak Thifa', 'Laksana', 2020, 5, 'Ranselo-dan-Galang.jpg', 'Buku Ranselo dan Galang menceritakan tentang seorang anak bernama Galang dan ransel biru bernama Ranselo yang bisa bicara. Ranselo selalu menemani Galang ke mana pun Galang pergi.'),
(6, 'Malin kundang', 'Dian Aprilia Dewi', ' Elex Media Komputindo', 2013, 222, 'malin kundang.jpeg', 'Legenda Malin Kundang berkisah tentang seorang anak yang durhaka pada ibunya dan karena itu dikutuk menjadi batu. Sebuah prangko dengan ilustrasi legenda Malin Kundang, tahun 1998. Cerita rakyat yang mirip juga dapat ditemukan di negara-negara lain di Asia Tenggara.'),
(7, '101 Dongeng Seru Sebelum Bobok', 'Fitri Haryani Nasution', 'Laksana', 2018, 10, '101.jpg', 'Cara terbaik menanamkan budi pekerti kepada anak adalah dengan cara membacakan dongeng. Anak akan mengerti mana yang perbuatan baik dan yang buruk serta akibatnya. Juga imajinasi anak akan berkembang saat berusaha mengikuti alur yang dibacakan. Buku ini berisi 101 dongeng yang disertai dengan ilustrasi keren.'),
(8, 'Kita, Kata, Cinta', 'Khrisna Pabichara', 'Diva Press', 2019, 4, 'Kita-Kata-Cinta.jpg', 'Buku Kita, Kata, dan Cinta karya Khrisna Pabichara berisi kisah cinta dan pembelajaran bahasa Indonesia. Buku ini juga berisi kritik halus terhadap rasa cinta kita terhadap bahasa Indonesia.');

-- --------------------------------------------------------

--
-- Table structure for table `kategoribuku`
--

CREATE TABLE IF NOT EXISTS `kategoribuku` (
  `kategoriID` int(11) NOT NULL,
  `namakategori` varchar(255) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `kategoribuku`
--

INSERT INTO `kategoribuku` (`kategoriID`, `namakategori`) VALUES
(1, 'dongeng'),
(4, 'fiksi remaja'),
(5, 'cerpen'),
(16, 'cerita rakyat');

-- --------------------------------------------------------

--
-- Table structure for table `kategoribuku_relasi`
--

CREATE TABLE IF NOT EXISTS `kategoribuku_relasi` (
  `kategoribukuID` int(11) NOT NULL,
  `bukuID` int(11) NOT NULL,
  `kategoriID` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `kategoribuku_relasi`
--

INSERT INTO `kategoribuku_relasi` (`kategoribukuID`, `bukuID`, `kategoriID`) VALUES
(2, 7, 1),
(7, 1, 4),
(8, 2, 4),
(9, 3, 4),
(10, 5, 5),
(11, 8, 4),
(12, 6, 16);

-- --------------------------------------------------------

--
-- Table structure for table `koleksipribadi`
--

CREATE TABLE IF NOT EXISTS `koleksipribadi` (
  `koleksiID` int(11) NOT NULL,
  `userID` int(11) NOT NULL,
  `bukuID` int(11) NOT NULL,
  `gambar` varchar(255) NOT NULL,
  `judul` varchar(255) NOT NULL,
  `penulis` varchar(255) NOT NULL,
  `penerbit` varchar(255) NOT NULL,
  `tahunterbit` year(4) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=71 DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `koleksipribadi`
--

INSERT INTO `koleksipribadi` (`koleksiID`, `userID`, `bukuID`, `gambar`, `judul`, `penulis`, `penerbit`, `tahunterbit`) VALUES
(70, 4, 1, 'Kamis-yang-Manis.jpg', 'kamis yang manis', 'John Steinbeck', 'Basabasi', 2019);

-- --------------------------------------------------------

--
-- Table structure for table `peminjaman`
--

CREATE TABLE IF NOT EXISTS `peminjaman` (
  `peminjamanID` int(11) NOT NULL,
  `userID` int(11) NOT NULL,
  `bukuID` int(11) NOT NULL,
  `tanggalpeminjaman` date NOT NULL,
  `tanggalpengembalian` date NOT NULL,
  `statuspeminjam` enum('dipinjam','dikembalikan') NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `peminjaman`
--

INSERT INTO `peminjaman` (`peminjamanID`, `userID`, `bukuID`, `tanggalpeminjaman`, `tanggalpengembalian`, `statuspeminjam`) VALUES
(12, 5, 2, '2025-01-20', '2025-01-22', 'dikembalikan'),
(14, 3, 1, '2025-01-21', '2025-01-22', 'dipinjam'),
(15, 7, 1, '2025-01-22', '2025-02-01', 'dikembalikan'),
(16, 8, 1, '2025-01-24', '2025-01-26', 'dikembalikan'),
(22, 3, 3, '2025-01-26', '2025-01-31', 'dikembalikan'),
(23, 3, 2, '2025-02-04', '2025-02-07', 'dikembalikan');

-- --------------------------------------------------------

--
-- Table structure for table `ulasanbuku`
--

CREATE TABLE IF NOT EXISTS `ulasanbuku` (
  `ulasanID` int(11) NOT NULL,
  `userID` int(11) NOT NULL,
  `bukuID` int(11) NOT NULL,
  `ulasan` text NOT NULL,
  `rating` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `ulasanbuku`
--

INSERT INTO `ulasanbuku` (`ulasanID`, `userID`, `bukuID`, `ulasan`, `rating`) VALUES
(1, 3, 1, 'bukunya sangat menarik', 4),
(2, 3, 3, 'waau', 3),
(3, 4, 2, 'bagus', 5),
(4, 3, 1, 'keren', 4),
(5, 6, 1, 'tidak sesuai judul', 1),
(6, 7, 6, 'bukunya kurang menarik', 3),
(8, 8, 3, 'bukunya menarik', 5);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `userID` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `nama_lengkap` varchar(255) NOT NULL,
  `alamat` text NOT NULL,
  `level` enum('admin','petugas','peminjam') NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`userID`, `username`, `password`, `email`, `nama_lengkap`, `alamat`, `level`) VALUES
(1, 'petugas', 'petugas', 'petugas@gmail.com', 'epenlina silalahi', 'kecamatan bahar utara unit 6kabupaten muaro jambi', 'petugas'),
(2, 'admin', 'admin', 'admin@admin.com', 'eka purwati', 'Jln. Trans Adonara 1', 'admin'),
(3, 'eka', 'eka123', 'eka@gmail.com', 'eka purwati', 'kecamatan bahar utara unit 6kabupaten muaro jambi', 'peminjam'),
(4, 'devi', 'devi123', 'devi@gmail.com', 'devi safira', 'ladang pris', 'peminjam'),
(5, 'noni', 'noni123', 'noni@gmail.com', 'noni astara', 'kecamatan bahar utara unit 12 desa sumber mulia rt 03', 'peminjam'),
(6, 'nadia', 'nadia123', 'nadiarahma@gimail.com', 'nadia rahma', 'kecamatan bahar utara unit 6\r\nkabupaten muaro jambi', 'peminjam'),
(7, 'stefani', 'pani123', 'stefani@gmail.com', 'Stefani Lumbanraja', 'kecamatan bahar utara unit 12 desa sumber mulya', 'peminjam'),
(8, 'jihan', 'jihan123', 'jiansfrsa1303@gmil.com', 'jihan marsa s', 'kecamatan bahar utara unit 19\r\nkabupaten muaro jambi', 'peminjam');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `buku`
--
ALTER TABLE `buku`
  ADD PRIMARY KEY (`bukuID`);

--
-- Indexes for table `kategoribuku`
--
ALTER TABLE `kategoribuku`
  ADD PRIMARY KEY (`kategoriID`);

--
-- Indexes for table `kategoribuku_relasi`
--
ALTER TABLE `kategoribuku_relasi`
  ADD PRIMARY KEY (`kategoribukuID`),
  ADD KEY `BukuID` (`bukuID`),
  ADD KEY `KategoriID` (`kategoriID`);

--
-- Indexes for table `koleksipribadi`
--
ALTER TABLE `koleksipribadi`
  ADD PRIMARY KEY (`koleksiID`),
  ADD KEY `UserID` (`userID`),
  ADD KEY `BukuID` (`bukuID`);

--
-- Indexes for table `peminjaman`
--
ALTER TABLE `peminjaman`
  ADD PRIMARY KEY (`peminjamanID`),
  ADD KEY `UserID` (`userID`),
  ADD KEY `BukuID` (`bukuID`);

--
-- Indexes for table `ulasanbuku`
--
ALTER TABLE `ulasanbuku`
  ADD PRIMARY KEY (`ulasanID`),
  ADD KEY `UserID` (`userID`),
  ADD KEY `BukuID` (`bukuID`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`userID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `buku`
--
ALTER TABLE `buku`
  MODIFY `bukuID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `kategoribuku`
--
ALTER TABLE `kategoribuku`
  MODIFY `kategoriID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=17;
--
-- AUTO_INCREMENT for table `kategoribuku_relasi`
--
ALTER TABLE `kategoribuku_relasi`
  MODIFY `kategoribukuID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT for table `koleksipribadi`
--
ALTER TABLE `koleksipribadi`
  MODIFY `koleksiID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=71;
--
-- AUTO_INCREMENT for table `peminjaman`
--
ALTER TABLE `peminjaman`
  MODIFY `peminjamanID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=24;
--
-- AUTO_INCREMENT for table `ulasanbuku`
--
ALTER TABLE `ulasanbuku`
  MODIFY `ulasanID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `userID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=9;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `kategoribuku_relasi`
--
ALTER TABLE `kategoribuku_relasi`
  ADD CONSTRAINT `kategoribuku_relasi_ibfk_2` FOREIGN KEY (`kategoriID`) REFERENCES `kategoribuku` (`kategoriID`),
  ADD CONSTRAINT `kategoribuku_relasi_ibfk_3` FOREIGN KEY (`bukuID`) REFERENCES `buku` (`bukuID`);

--
-- Constraints for table `koleksipribadi`
--
ALTER TABLE `koleksipribadi`
  ADD CONSTRAINT `koleksipribadi_ibfk_3` FOREIGN KEY (`userID`) REFERENCES `user` (`userID`),
  ADD CONSTRAINT `koleksipribadi_ibfk_4` FOREIGN KEY (`bukuID`) REFERENCES `buku` (`bukuID`);

--
-- Constraints for table `peminjaman`
--
ALTER TABLE `peminjaman`
  ADD CONSTRAINT `peminjaman_ibfk_3` FOREIGN KEY (`userID`) REFERENCES `user` (`userID`),
  ADD CONSTRAINT `peminjaman_ibfk_4` FOREIGN KEY (`bukuID`) REFERENCES `buku` (`bukuID`);

--
-- Constraints for table `ulasanbuku`
--
ALTER TABLE `ulasanbuku`
  ADD CONSTRAINT `ulasanbuku_ibfk_2` FOREIGN KEY (`userID`) REFERENCES `user` (`userID`),
  ADD CONSTRAINT `ulasanbuku_ibfk_3` FOREIGN KEY (`bukuID`) REFERENCES `buku` (`bukuID`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
