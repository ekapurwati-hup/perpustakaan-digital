<?php
include 'koneksi.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);
    $email = trim($_POST['email']);
    $nama_lengkap = trim($_POST['nama_lengkap']);
    $alamat = trim($_POST['alamat']);

    // Validasi data
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo "<script>alert('Format email tidak valid.');</script>";
    } elseif (strlen($password) < 6) {
        echo "<script>alert('Password harus terdiri dari minimal 6 karakter.');</script>";
    } else {
        // Cek apakah username sudah ada
        $check_sql = "SELECT * FROM user WHERE username = ?";
        $stmt_check = $conn->prepare($check_sql);
        $stmt_check->bind_param("s", $username);
        $stmt_check->execute();
        $result_check = $stmt_check->get_result();

        if ($result_check->num_rows > 0) {
            echo "<script>alert('Username sudah digunakan.');</script>";
        } else {
            // Hash password
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);

            // Masukkan data ke tabel user
            $sql = "INSERT INTO user (username, password, email, nama_lengkap, alamat, level) VALUES (?, ?, ?, ?, ?, 'peminjam')";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("sssss", $username, $password, $email, $nama_lengkap, $alamat);

            if ($stmt->execute()) {
                echo "<script>alert('Registrasi berhasil! Silakan login.');</script>";
                header("Location: login.php");
                exit;
            } else {
                echo "<script>alert('Registrasi gagal. Coba lagi.');</script>";
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Halaman Registrasi</title>
    <link href="../img/perpus.png" rel="shortcut icon" />
    <style>
        body {
            font-family: Arial, sans-serif;
            /*background: linear-gradient(to bottom,rgb(17, 39, 86),rgb(9, 24, 49));*/
            background-image: url('gambar.jpg');
            background-size: 100%;
            color: #333;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        .register-container {
            background: #fff;
            padding: 20px 30px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
            width: 100%;
            max-width: 400px;
            text-align: center;
        }
        .register-container h2 {
            margin-bottom: 20px;
            color:rgb(5, 3, 8);
        }
        .register-container input, .register-container textarea {
            width: 100%;
            padding: 10px;
            margin: 10px 0;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 16px;
        }
        .register-container textarea {
            resize: none;
            height: 80px;
        }
        .register-container button {
            width: 100%;
            padding: 10px;
            background:rgb(9, 8, 11);
            color: #fff;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            cursor: pointer;
            transition: background 0.3s;
        }
        .register-container button:hover {
            background:rgb(5, 44, 111);
        }
        .register-container p {
            margin-top: 15px;
        }
        .register-container a {
            color:rgb(17, 107, 203);
            text-decoration: none;
        }
        .register-container a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="register-container">
        <h2>Registrasi Akun Peminjam</h2>
        <form action="" method="POST">
            <input type="text" name="username" placeholder="Username" required>
            <input type="password" name="password" placeholder="Password (min. 6 karakter)" required>
            <input type="email" name="email" placeholder="Email" required>
            <input type="text" name="nama_lengkap" placeholder="Nama Lengkap" required>
            <textarea name="alamat" placeholder="Alamat" required></textarea>
            <button type="submit">Daftar</button>
        </form>
        <p>Sudah punya akun? <a href="login.php">Login di sini</a></p>
    </div>
</body>
</html>

