<?php
session_start();
include 'koneksi.php';

// Periksa jika ada koleksiID yang diteruskan
if (isset($_GET['koleksiID'])) {
    $koleksiID = $_GET['koleksiID'];

    // Pastikan userID tersedia dalam sesi
    if (isset($_SESSION['userID'])) {
        $userID = $_SESSION['userID'];

        // Query untuk menghapus buku dari koleksi pribadi
        $sql = "DELETE FROM koleksipribadi WHERE koleksiID = '$koleksiID' AND userID = '$userID'";

        if ($conn->query($sql) === TRUE) {
            // Redirect ke koleksi_pribadi.php jika berhasil
            header("Location: koleksi_pribadi.php?message=success");
            exit();
        } else {
            echo "Error: " . $conn->error;
        }
    } else {
        echo "User tidak terautentikasi.";
    }
} else {
    echo "Koleksi ID tidak ditemukan.";
}

$conn->close();
?>
