<?php
session_start();
include 'koneksi.php';

// Cek apakah user sudah login
if (!isset($_SESSION['userID'])) {
    echo "<script>alert('Anda harus login terlebih dahulu!'); window.location.href='../login.php';</script>";
    exit();
}

// Ambil data peminjaman buku untuk user yang sedang login
$userID = $_SESSION['userID'];
$sqlPeminjaman = "SELECT peminjaman.*, buku.judul, user.username 
                  FROM peminjaman 
                  JOIN buku ON peminjaman.bukuID = buku.bukuID
                  JOIN user ON peminjaman.userID = user.userID
                  WHERE peminjaman.userID = '$userID' AND peminjaman.statuspeminjam = 'dipinjam'";

$resultPeminjaman = $conn->query($sqlPeminjaman);

if ($resultPeminjaman->num_rows == 0) {
    echo "<script>alert('Tidak ada peminjaman buku aktif.'); window.location.href='data_buku.php';</script>";
    exit();
}

if (isset($_GET['kembalikan'])) {
    $peminjamanID = $_GET['kembalikan'];
    
    // Update status peminjaman menjadi 'dikembalikan'
    $sqlKembalikan = "UPDATE peminjaman SET statuspeminjam = 'dikembalikan' WHERE peminjamanID = '$peminjamanID'";

    // Ambil bukuID dari peminjaman untuk mengupdate stok
    $sqlGetBukuID = "SELECT bukuID FROM peminjaman WHERE peminjamanID = '$peminjamanID'";
    $result = $conn->query($sqlGetBukuID);
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $bukuID = $row['bukuID'];

        // Update stok buku (menambah 1)
        $sqlUpdateStok = "UPDATE buku SET stok = stok + 1 WHERE bukuID = '$bukuID'";

        if ($conn->query($sqlKembalikan) === TRUE && $conn->query($sqlUpdateStok) === TRUE) {
            echo "<script>alert('Buku berhasil dikembalikan!'); window.location.href='pengembalian_buku.php';</script>";
        } else {
            echo "Error: " . $conn->error;
        }
    }
}

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>Perpustakaan Digital</title>
    <link href="../img/perpus.png" rel="shortcut icon" />
    <link href="https://cdn.jsdelivr.net/npm/simple-datatables@7.1.2/dist/style.min.css" rel="stylesheet" />
    <link href="css/styles.css" rel="stylesheet" />
    <script src="https://use.fontawesome.com/releases/v6.3.0/js/all.js" crossorigin="anonymous"></script>
</head>
<body class="sb-nav-fixed">
<nav class="sb-topnav navbar navbar-expand navbar-dark bg-dark">
            <!-- Navbar Brand-->
            <a class="navbar-brand ps-3" href="index.html">Perpustakaan Digital</a>
            <!-- Sidebar Toggle-->
            <button class="btn btn-link btn-sm order-1 order-lg-0 me-4 me-lg-0" id="sidebarToggle" href="#!"><i class="fas fa-bars"></i></button>
            <!-- Navbar Search-->
            <form class="d-none d-md-inline-block form-inline ms-auto me-0 me-md-3 my-2 my-md-0">
                <div class="input-group">
                    
                </div>
            </form>
            <!-- Navbar-->
            <ul class="navbar-nav ms-auto ms-md-0 me-3 me-lg-4">
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" id="navbarDropdown" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false"><i class="fas fa-user fa-fw"></i></a>
                    <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                        
                        <li><hr class="dropdown-divider" /></li>
                        <li><a class="dropdown-item" href="../login.php">Logout</a></li>
                    </ul>
                </li>
            </ul>
        </nav>
    <div id="layoutSidenav">
        <div id="layoutSidenav_nav">
            <nav class="sb-sidenav accordion sb-sidenav-dark" id="sidenavAccordion">
                <div class="sb-sidenav-menu">
                    <div class="nav">
                        <div class="sb-sidenav-menu-heading">Core</div>
                        <a class="nav-link" href="peminjam.php">
                            <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                            Dashboard
                        </a>
                        <a class="nav-link" href="data_buku.php">
                                <div class="sb-nav-link-icon"><i class="fas fa-book"></i></div>
                                Data Buku
                            </a>
                            <a class="nav-link" href="koleksi_pribadi.php">
                                <div class="sb-nav-link-icon"><i class="fas fa-book"></i></div>
                                Koleksi Pribadi
                            </a>
                            <a class="nav-link" href="ulasan_buku.php">
                                <div class="sb-nav-link-icon"><i class="fas fa-book"></i></div>
                                Ulasan Buku
                            </a>
                            <a class="nav-link" href="pengembalian_buku.php">
                                <div class="sb-nav-link-icon"><i class="fas fa-book-open"></i></div>
                                Pengembalian
                            </a>
                        <a class="nav-link" href="../login.php">
                            <div class="sb-nav-link-icon"><i class="fa fa-power-off"></i></div>
                            Logout
                        </a>
                    </div>
                </div>
                
            </nav>
        </div>
        <div id="layoutSidenav_content">
            <main>
                <div class="container-fluid px-4">
                    <h1 class="mt-4">Perpustakaan Digital</h1>
                    <ol class="breadcrumb mb-4">
                        <li class="breadcrumb-item active">Dashboard</li>
                    </ol>
                    
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <div>
                            <i class="fas fa-table me-1"></i>
                            Data Buku
                        </div>
                    </div>

                    <div class="card mb-4">
                    <div class="card-body">
    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
    <thead>
            <tr>
                <th>No</th>
                <th>Nama Pengguna</th>
                <th>Judul Buku</th>
                <th>Tanggal Peminjaman</th>
                <th>Tanggal Pengembalian</th>
                <th>Status</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
        <?php
                while ($peminjaman = $resultPeminjaman->fetch_assoc()) {
                    echo "<tr>
                        <td>{$peminjaman['peminjamanID']}</td>
                        <td>{$peminjaman['username']}</td>
                        <td>{$peminjaman['judul']}</td>
                        <td>{$peminjaman['tanggalpeminjaman']}</td>
                        <td>{$peminjaman['tanggalpengembalian']}</td>
                        <td>{$peminjaman['statuspeminjam']}</td>
                        <td>
                            <a href='pengembalian_buku.php?kembalikan={$peminjaman['peminjamanID']}' class='btn btn-success'>Kembalikan</a>
                        </td>
                    </tr>";
                }
                ?>
        </tbody>
    </table>
</div>

                    </div>

                </div>
            </main>
            <footer class="py-4 bg-light mt-auto">
                <div class="container-fluid px-4">
                    <div class="d-flex align-items-center justify-content-between small">
                        <div class="text-muted">Copyright &copy; Your Website 2025</div>
                        <div>
                            
                        </div>
                    </div>
                </div>
            </footer>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
    <script src="js/scripts.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.8.0/Chart.min.js" crossorigin="anonymous"></script>
    <script src="assets/demo/chart-area-demo.js"></script>
    <script src="assets/demo/chart-bar-demo.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/simple-datatables@7.1.2/dist/umd/simple-datatables.min.js" crossorigin="anonymous"></script>
    <script src="js/datatables-simple-demo.js"></script>
</body>
</html>
