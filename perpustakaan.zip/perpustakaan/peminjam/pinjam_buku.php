<?php
session_start();
include 'koneksi.php';

// Cek apakah user sudah login
if (!isset($_SESSION['userID'])) {
    echo "<script>alert('Anda harus login terlebih dahulu!'); window.location.href='login.php';</script>";
    exit();
}

$userID = $_SESSION['userID']; // Ambil userID dari sesi
$bukuID = $_GET['id']; // Ambil bukuID dari URL

// Ambil detail buku
$sqlBuku = "SELECT * FROM buku WHERE bukuID = '$bukuID'";
$resultBuku = $conn->query($sqlBuku);
if ($resultBuku->num_rows == 0) {
    echo "<script>alert('Buku tidak ditemukan!'); window.location.href='data_buku.php';</script>";
    exit();
}
$buku = $resultBuku->fetch_assoc();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $tanggalpeminjaman = $_POST['tanggalpeminjaman'];
    $tanggalpengembalian = $_POST['tanggalpengembalian'];

    // Misalnya setelah berhasil menambahkan data peminjaman
$sqlPinjam = "INSERT INTO peminjaman (userID, bukuID, tanggalpeminjaman, tanggalpengembalian, statuspeminjam)
VALUES ('$userID', '$bukuID', '$tanggalpeminjaman', '$tanggalpengembalian', 'dipinjam')";

// Update stok buku (mengurangi 1)
$sqlUpdateStok = "UPDATE buku SET stok = stok - 1 WHERE bukuID = '$bukuID'";

if ($conn->query($sqlPinjam) === TRUE && $conn->query($sqlUpdateStok) === TRUE) {
echo "<script>alert('Buku berhasil dipinjam!'); window.location.href='data_buku.php';</script>";
} else {
echo "Error: " . $conn->error;
}
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pinjam Buku</title>
    <link href="../img/perpus.png" rel="shortcut icon" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-5">
    <h2>Pinjam Buku</h2>
    <form method="POST">
        <div class="mb-3">
            <label for="judul" class="form-label">Judul Buku</label>
            <input type="text" class="form-control" id="judul" value="<?= $buku['judul']; ?>" readonly>
        </div>
        <div class="mb-3">
            <label for="penulis" class="form-label">Penulis</label>
            <input type="text" class="form-control" id="penulis" value="<?= $buku['penulis']; ?>" readonly>
        </div>
        <div class="mb-3">
            <label for="tanggalpeminjaman" class="form-label">Tanggal Peminjaman</label>
            <input type="date" class="form-control" id="tanggalpeminjaman" name="tanggalpeminjaman" value="<?= date('Y-m-d'); ?>" readonly>
        </div>
        <div class="mb-3">
            <label for="tanggalpengembalian" class="form-label">Tanggal Pengembalian</label>
            <input type="date" class="form-control" id="tanggalpengembalian" name="tanggalpengembalian" required>
        </div>
        <button type="submit" class="btn btn-primary">Pinjam</button>
        <a href="data_buku.php" class="btn btn-secondary">Kembali</a>
    </form>
</div>
</body>
</html>
