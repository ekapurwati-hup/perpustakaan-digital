<?php
include 'koneksi.php';

// Memeriksa apakah parameter id ada
if (isset($_GET['id'])) {
    $bukuID = $_GET['id'];

    // Query untuk mendapatkan detail buku berdasarkan bukuID
    $sql = "SELECT * FROM buku WHERE bukuID = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $bukuID);
    $stmt->execute();
    $result = $stmt->get_result();

    // Memeriksa apakah buku ditemukan
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
    } else {
        echo "<script>alert('Buku tidak ditemukan'); window.location.href='data_buku.php';</script>";
        exit;
    }
} else {
    echo "<script>alert('ID Buku tidak valid'); window.location.href='data_buku.php';</script>";
    exit;
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detail Buku</title>
    <link href="../img/perpus.png" rel="shortcut icon" />
    <link href="css/styles.css" rel="stylesheet" />
</head>
<body>
    <div class="container">
        <h1>Detail Buku</h1>
        <div class="card">
            <div class="card-body">
                <h5 class="card-title"><?= htmlspecialchars($row['judul']) ?></h5>
                <p class="card-text"><strong>Penulis:</strong> <?= htmlspecialchars($row['penulis']) ?></p>
                <p class="card-text"><strong>Penerbit:</strong> <?= htmlspecialchars($row['penerbit']) ?></p>
                <p class="card-text"><strong>Tahun Terbit:</strong> <?= htmlspecialchars($row['tahunterbit']) ?></p>
                <p class="card-text"><strong>Stok:</strong> <?= htmlspecialchars($row['stok']) ?></p>
                <p class="card-text"><strong>Keterangan:</strong> <?= htmlspecialchars($row['keterangan']) ?></p> <!-- Tambahkan keterangan -->
                <img src="../admin/uploads/<?= htmlspecialchars($row['gambar']) ?>" alt="Gambar Buku" width="200">
            </div>
        </div>
        <a href="data_buku.php" class="btn btn-primary mt-3">Kembali</a>
    </div>
</body>
</html>
