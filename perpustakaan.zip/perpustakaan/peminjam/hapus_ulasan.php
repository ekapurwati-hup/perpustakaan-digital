<?php
session_start();
include 'koneksi.php';

// Pastikan pengguna login sebagai peminjam
if (!isset($_SESSION['level']) || $_SESSION['level'] != 'peminjam') {
    header("Location: ../login.php");
    exit;
}

// Pastikan ulasanID ada dalam POST
if (isset($_POST['ulasanID'])) {
    $ulasanID = $_POST['ulasanID'];
    $userID = $_SESSION['userID']; // Ambil userID yang sedang login

    // Periksa apakah ulasan ini milik user yang login
    $cekQuery = "SELECT * FROM ulasanbuku WHERE ulasanID = ? AND userID = ?";
    $stmt = $conn->prepare($cekQuery);
    $stmt->bind_param("ii", $ulasanID, $userID);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        // Jika ulasan ditemukan dan milik user yang login, hapus ulasan
        $hapusQuery = "DELETE FROM ulasanbuku WHERE ulasanID = ?";
        $stmt = $conn->prepare($hapusQuery);
        $stmt->bind_param("i", $ulasanID);
        if ($stmt->execute()) {
            echo "<script>alert('Ulasan berhasil dihapus!'); window.location.href='peminjam.php';</script>";
        } else {
            echo "<script>alert('Gagal menghapus ulasan!'); window.location.href='peminjam.php';</script>";
        }
    } else {
        echo "<script>alert('Anda tidak berhak menghapus ulasan ini!'); window.location.href='peminjam.php';</script>";
    }

    $stmt->close();
}

$conn->close();
?>
