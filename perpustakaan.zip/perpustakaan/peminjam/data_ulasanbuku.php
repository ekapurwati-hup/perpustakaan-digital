<?php
session_start();
if (!isset($_SESSION['userID'])) {
    header("Location: ../login.php");
    exit;
}

include 'koneksi.php';

$userID = $_SESSION['userID'];  // Ambil userID dari session yang sudah login

// Ambil bukuID dari parameter URL
$bukuID = $_GET['id'];

// Query untuk mengambil data buku berdasarkan bukuID yang dipilih
$sql = "SELECT * FROM buku WHERE bukuID = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $bukuID);
$stmt->execute();
$result = $stmt->get_result();
$book = $result->fetch_assoc();

// Proses jika form disubmit
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $ulasan = $_POST['ulasan'];
    $rating = $_POST['rating'];

    // Simpan ulasan ke database
    $sql = "INSERT INTO ulasanbuku (userID, bukuID, ulasan, rating) VALUES (?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("iisi", $userID, $bukuID, $ulasan, $rating);
    if ($stmt->execute()) {
        $message = "Ulasan berhasil ditambahkan!";
        $messageClass = "alert-success";
    } else {
        $message = "Gagal menambahkan ulasan.";
        $messageClass = "alert-danger";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>Ulasan Buku</title>
    <link href="../img/perpus.png" rel="shortcut icon" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" />
    <script src="https://use.fontawesome.com/releases/v6.3.0/js/all.js" crossorigin="anonymous"></script>
</head>
<body class="sb-nav-fixed">

    <div id="layoutSidenav_content">
        <main>
            <div class="container-fluid px-4">
                <h1 class="mt-4">Ulasan Buku</h1>
                
                <?php if (isset($message)): ?>
                    <div class="alert <?php echo $messageClass; ?>" role="alert">
                        <?php echo $message; ?>
                    </div>
                <?php endif; ?>

                <div class="card shadow-sm mt-4">
                    <div class="card-body">
                        <form method="POST" action="">
                            <div class="mb-3">
                                <label for="judul_buku" class="form-label">Judul Buku:</label>
                                <input type="text" class="form-control" id="judul_buku" value="<?php echo $book['judul']; ?>" readonly>
                            </div>

                            <div class="mb-3">
                                <label for="ulasan" class="form-label">Ulasan:</label>
                                <textarea name="ulasan" class="form-control" id="ulasan" rows="4" required></textarea>
                            </div>

                            <div class="mb-3">
                                <label for="rating" class="form-label">Rating (1-5):</label>
                                <input type="number" name="rating" class="form-control" id="rating" min="1" max="5" required>
                            </div>

                            <button type="submit" class="btn btn-primary">Kirim Ulasan</button>
                            <a href="ulasan_buku.php" class="btn btn-secondary">Kembali</a>
                        </form>
                    </div>
                </div>
            </div>
        </main>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
