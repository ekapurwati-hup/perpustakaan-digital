<?php
session_start();
include 'koneksi.php';

// Filter berdasarkan pencarian
$search = isset($_GET['search']) ? $_GET['search'] : '';

// Membuat klausa WHERE berdasarkan pencarian
$whereClause = '';
if ($search) {
    $whereClause = "WHERE judul LIKE '%$search%'";
}

// Ambil data buku dengan filter pencarian
$sqlBuku = "SELECT * FROM buku $whereClause";
$resultBuku = $conn->query($sqlBuku);

// Mendapatkan tanggal cetak saat ini
$tanggalCetak = date('d F Y');

// Ambil username dari session
$username = isset($_SESSION['username']) ? $_SESSION['username'] : '';

// Ambil nama lengkap pengguna dari database
$sqlNamaLengkap = "SELECT nama_lengkap FROM user WHERE username = '$username'";
$resultNamaLengkap = $conn->query($sqlNamaLengkap);
$namaLengkap = '';

if ($resultNamaLengkap->num_rows > 0) {
    $row = $resultNamaLengkap->fetch_assoc();
    $namaLengkap = $row['nama_lengkap'];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cetak Laporan Data Buku</title>
    <link href="../img/perpus.png" rel="shortcut icon" />
    <style>
        /* Styling untuk halaman cetak */
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }
        table, th, td {
            border: 1px solid black;
        }
        th, td {
            padding: 8px;
            text-align: left;
        }
        @media print {
            .no-print {
                display: none;
            }
        }
        h1 {
            text-align: center;
            line-height: 1.2;
        }
        .footer {
            margin-top: 40px;
            display: flex;
            justify-content: space-between;
            font-size: 14px;
        }
        .footer-left, .footer-right{
            width: 45%;
            margin-left:30px; /* Menggeser elemen ke kanan */
        }

        .footer-right {
            margin-left:100px; /* Menggeser elemen ke kanan */
            width: 45%; /* Menentukan lebar elemen */
            text-align: left; /* Membuat teks di dalam elemen rata kiri */
            padding-left: 400px; /* Pastikan padding kiri diatur sesuai kebutuhan */
        }
    </style>
</head>
<body>

    <h1>
        LAPORAN<br>
        DATA BUKU<br>
        APLIKASI PERPUSTAKAAN DIGITAL
    </h1>
    
    <table>
        <thead>
            <tr>
                <th>Judul Buku</th>
                <th>Penulis</th>
                <th>Penerbit</th>
                <th>Tahun Terbit</th>
                <th>Stok</th>
            </tr>
        </thead>
        <tbody>
            <?php
            if ($resultBuku->num_rows > 0) {
                while ($buku = $resultBuku->fetch_assoc()) {
                    echo "<tr>
                            <td>{$buku['judul']}</td>
                            <td>{$buku['penulis']}</td>
                            <td>{$buku['penerbit']}</td>
                            <td>{$buku['tahunterbit']}</td>
                            <td>{$buku['stok']}</td>
                        </tr>";
                }
            } else {
                echo "<tr>
                        <td colspan='5' style='text-align: center;'>Tidak ada data buku</td>
                    </tr>";
            }
            ?>
        </tbody>
    </table>

    <!-- Footer with Kepala Sekolah info and Koordinator Perpustakaan -->
    <div class="footer">
        
        <div class="footer-right">
            <p>Jambi, <?php echo $tanggalCetak; ?></p>
            <p>Koordinator Perpustakaan</p>
            <br>
            <br>
            <br>
            <p><strong><?php echo $namaLengkap ? $namaLengkap : 'Nama Koordinator Perpustakaan'; ?></strong></p>
        </div>
    </div>

    <script>
        // Men-trigger print otomatis setelah halaman dimuat
        window.onload = function() {
            window.print();
            window.onafterprint = function() {
                window.close(); // Menutup tab setelah print
            }
        }
    </script>
</body>
</html>
