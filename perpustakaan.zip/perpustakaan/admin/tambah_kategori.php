<?php
include 'koneksi.php';

// Proses tambah kategori
if (isset($_POST['tambah_kategori'])) {
    $namaKategori = $_POST['namaKategori'];
    $query = "INSERT INTO kategoribuku (namakategori) VALUES ('$namaKategori')";
    if (mysqli_query($conn, $query)) {
        echo "<script>alert('Kategori berhasil ditambahkan!'); window.location='tambah_kategori.php';</script>";
    } else {
        echo "<script>alert('Gagal menambahkan kategori!');</script>";
    }
}

// Proses hapus kategori
if (isset($_GET['hapus'])) {
    $kategoriID = $_GET['hapus'];

    // Hapus relasi kategori dengan buku dulu
    mysqli_query($conn, "DELETE FROM kategoribuku_relasi WHERE kategoriID = '$kategoriID'");

    // Hapus kategori
    $hapusKategori = "DELETE FROM kategoribuku WHERE kategoriID = '$kategoriID'";
    if (mysqli_query($conn, $hapusKategori)) {
        echo "<script>alert('Kategori berhasil dihapus!'); window.location='tambah_kategori.php';</script>";
    } else {
        echo "<script>alert('Gagal menghapus kategori!');</script>";
    }
}

// Proses edit kategori
if (isset($_POST['edit_kategori'])) {
    $kategoriID = $_POST['kategoriID'];
    $namaKategori = $_POST['namaKategori'];
    
    $query = "UPDATE kategoribuku SET namakategori='$namaKategori' WHERE kategoriID='$kategoriID'";
    if (mysqli_query($conn, $query)) {
        echo "<script>alert('Kategori berhasil diperbarui!'); window.location='tambah_kategori.php';</script>";
    } else {
        echo "<script>alert('Gagal memperbarui kategori!');</script>";
    }
}

// Proses memasukkan buku ke kategori
if (isset($_POST['tambah_buku_kategori'])) {
    $bukuID = $_POST['bukuID'];
    $kategoriID = $_POST['kategoriID'];

    // Cek apakah buku sudah ada dalam kategori ini
    $cekQuery = "SELECT * FROM kategoribuku_relasi WHERE bukuID = '$bukuID' AND kategoriID = '$kategoriID'";
    $cekResult = mysqli_query($conn, $cekQuery);

    if (mysqli_num_rows($cekResult) == 0) {
        $insertQuery = "INSERT INTO kategoribuku_relasi (bukuID, kategoriID) VALUES ('$bukuID', '$kategoriID')";
        if (mysqli_query($conn, $insertQuery)) {
            echo "<script>alert('Buku berhasil dimasukkan ke kategori!'); window.location='tambah_kategori.php';</script>";
        } else {
            echo "<script>alert('Gagal menambahkan buku ke kategori!');</script>";
        }
    } else {
        echo "<script>alert('Buku sudah ada di kategori ini!');</script>";
    }
}

// Ambil data kategori jika ingin diedit
$editKategori = "";
if (isset($_GET['edit'])) {
    $kategoriID = $_GET['edit'];
    $query = "SELECT * FROM kategoribuku WHERE kategoriID = '$kategoriID'";
    $result = mysqli_query($conn, $query);
    $row = mysqli_fetch_assoc($result);
    $editKategori = $row['namakategori'];
}



// Proses tambah buku ke kategori
if (isset($_POST['tambah_buku_kategori'])) {
    $bukuID = $_POST['bukuID'];
    $kategoriID = $_POST['kategoriID'];

    // Cek apakah buku sudah ada dalam kategori ini
    $cekQuery = "SELECT * FROM kategoribuku_relasi WHERE bukuID = '$bukuID'";
    $cekResult = mysqli_query($conn, $cekQuery);

    if (mysqli_num_rows($cekResult) == 0) {
        $insertQuery = "INSERT INTO kategoribuku_relasi (bukuID, kategoriID) VALUES ('$bukuID', '$kategoriID')";
        if (mysqli_query($conn, $insertQuery)) {
            echo "<script>alert('Buku berhasil dimasukkan ke kategori!'); window.location='tambah_kategori.php';</script>";
        } else {
            echo "<script>alert('Gagal menambahkan buku ke kategori!');</script>";
        }
    } else {
        echo "<script>alert('Buku sudah ada di kategori ini!');</script>";
    }
}

// Proses edit kategori buku
if (isset($_POST['edit_kategori_buku'])) {
    $bukuID = $_POST['bukuID'];
    $kategoriID = $_POST['kategoriID'];

    $updateQuery = "UPDATE kategoribuku_relasi SET kategoriID='$kategoriID' WHERE bukuID='$bukuID'";
    if (mysqli_query($conn, $updateQuery)) {
        echo "<script>alert('Kategori buku berhasil diperbarui!'); window.location='tambah_kategori.php';</script>";
    } else {
        echo "<script>alert('Gagal memperbarui kategori buku!');</script>";
    }
}

// Ambil data buku yang ingin diedit
$editBukuID = "";
$editKategoriID = "";
if (isset($_GET['edit_buku'])) {
    $bukuID = $_GET['edit_buku'];
    $query = "SELECT * FROM kategoribuku_relasi WHERE bukuID = '$bukuID'";
    $result = mysqli_query($conn, $query);
    $row = mysqli_fetch_assoc($result);
    $editBukuID = $row['bukuID'];
    $editKategoriID = $row['kategoriID'];
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kelola Kategori</title>
    <link href="../img/perpus.png" rel="shortcut icon" />
    <style>
        .container { width: 50%; margin: 20px auto; }
        table { width: 100%; border-collapse: collapse; }
        table, th, td { border: 1px solid black; text-align: center; }
        th, td { padding: 10px; }
        .btn { padding: 5px 10px; text-decoration: none; border-radius: 4px; }
        .btn-danger { background-color: red; color: white; }
        .btn-danger:hover { background-color: darkred; }
        .btn-edit { background-color: orange; color: white; }
        .btn-edit:hover { background-color: darkorange; }
    </style>
</head>
<body>

<div class="container">
    <h2><?php echo isset($_GET['edit']) ? 'Edit Kategori' : 'Tambah Kategori'; ?></h2>
    <form method="POST">
        <input type="hidden" name="kategoriID" value="<?php echo isset($_GET['edit']) ? $kategoriID : ''; ?>">
        <label>Nama Kategori:</label>
        <input type="text" name="namaKategori" value="<?php echo $editKategori; ?>" required>
        <button type="submit" name="<?php echo isset($_GET['edit']) ? 'edit_kategori' : 'tambah_kategori'; ?>">
            <?php echo isset($_GET['edit']) ? 'Update' : 'Tambah'; ?>
        </button>
        <a href="data_bukuadmin.php">Kembali</a>
    </form>

    <h2>Daftar Kategori</h2>
    <table>
        <thead>
            <tr>
                <th>No</th>
                <th>Nama Kategori</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $query = "SELECT * FROM kategoribuku";
            $result = mysqli_query($conn, $query);
            $no = 1;
            while ($row = mysqli_fetch_assoc($result)) {
                echo "<tr>";
                echo "<td>$no</td>";
                echo "<td>{$row['namakategori']}</td>";
                echo "<td>
                        <a href='tambah_kategori.php?edit={$row['kategoriID']}' class='btn btn-edit'>Edit</a>
                        <a href='tambah_kategori.php?hapus={$row['kategoriID']}' class='btn btn-danger' onclick='return confirm(\"Yakin ingin menghapus kategori ini?\")'>Hapus</a>
                      </td>";
                echo "</tr>";
                $no++;
            }
            ?>
        </tbody>
    </table>

    <h2>Masukkan Buku ke Kategori</h2>
    <form method="POST">
        <label>Pilih Buku:</label>
        <select name="bukuID" required>
            <option value="">Pilih Buku</option>
            <?php
            $bukuQuery = "SELECT * FROM buku";
            $bukuResult = mysqli_query($conn, $bukuQuery);
            while ($buku = mysqli_fetch_assoc($bukuResult)) {
                echo "<option value='{$buku['bukuID']}'>{$buku['judul']}</option>";
            }
            ?>
        </select>

        <label>Pilih Kategori:</label>
        <select name="kategoriID" required>
            <option value="">Pilih Kategori</option>
            <?php
            $kategoriQuery = "SELECT * FROM kategoribuku";
            $kategoriResult = mysqli_query($conn, $kategoriQuery);
            while ($kategori = mysqli_fetch_assoc($kategoriResult)) {
                echo "<option value='{$kategori['kategoriID']}'>{$kategori['namakategori']}</option>";
            }
            ?>
        </select>

        <button type="submit" name="tambah_buku_kategori">Tambah</button>
    </form>

    <h2>Edit Kategori Buku</h2>
    <form method="POST">
        <label>Pilih Buku:</label>
        <select name="bukuID" required>
            <option value="">Pilih Buku</option>
            <?php
            $bukuQuery = "SELECT * FROM buku";
            $bukuResult = mysqli_query($conn, $bukuQuery);
            while ($buku = mysqli_fetch_assoc($bukuResult)) {
                $selected = ($buku['bukuID'] == $editBukuID) ? "selected" : "";
                echo "<option value='{$buku['bukuID']}' $selected>{$buku['judul']}</option>";
            }
            ?>
        </select>

        <label>Pilih Kategori Baru:</label>
        <select name="kategoriID" required>
            <option value="">Pilih Kategori</option>
            <?php
            $kategoriQuery = "SELECT * FROM kategoribuku";
            $kategoriResult = mysqli_query($conn, $kategoriQuery);
            while ($kategori = mysqli_fetch_assoc($kategoriResult)) {
                $selected = ($kategori['kategoriID'] == $editKategoriID) ? "selected" : "";
                echo "<option value='{$kategori['kategoriID']}' $selected>{$kategori['namakategori']}</option>";
            }
            ?>
        </select>

        <button type="submit" name="edit_kategori_buku">Update</button>
    </form>

    <h2>Daftar Buku per Kategori</h2>
    <table>
        <thead>
            <tr>
                <th>No</th>
                <th>Judul Buku</th>
                <th>Kategori</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $query = "SELECT b.bukuID, b.judul, k.namakategori 
                      FROM kategoribuku_relasi kr
                      JOIN buku b ON kr.bukuID = b.bukuID
                      JOIN kategoribuku k ON kr.kategoriID = k.kategoriID";
            $result = mysqli_query($conn, $query);
            $no = 1;
            while ($row = mysqli_fetch_assoc($result)) {
                echo "<tr>";
                echo "<td>$no</td>";
                echo "<td>{$row['judul']}</td>";
                echo "<td>{$row['namakategori']}</td>";
                echo "<td>
                        <a href='tambah_kategori.php?edit_buku={$row['bukuID']}' class='btn btn-edit'>Edit</a>
                      </td>";
                echo "</tr>";
                $no++;
            }
            ?>
        </tbody>
    </table>
    </table>
</div>

</body>
</html>
