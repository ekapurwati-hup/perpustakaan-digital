<?php
include 'koneksi.php';

if (isset($_GET['userID'])) {
    $userID = $_GET['userID'];

    $sql = "SELECT * FROM user WHERE userID = '$userID'";
    $result = mysqli_query($conn, $sql);
    $data = mysqli_fetch_assoc($result);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];
    $email = $_POST['email'];
    $nama_lengkap = $_POST['nama_lengkap'];
    $alamat = $_POST['alamat'];
    $level = $_POST['level'];

    $password_hashed = md5($password);

    $sql = "UPDATE user SET 
                username = '$username', 
                password = '$password', 
                email = '$email', 
                nama_lengkap = '$nama_lengkap', 
                alamat = '$alamat', 
                level = '$level' 
            WHERE userID = '$userID'";

    if (mysqli_query($conn, $sql)) {
        echo "<script>
                alert('Data berhasil diperbarui!');
                window.location.href = 'data_user.php';
              </script>";
    } else {
        echo "Error: " . mysqli_error($conn);
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Perpustakaan Digita</title>
    <link href="../img/perpus.png" rel="shortcut icon" />
    <style>
    .form-container {
        width: 50%;
        margin: 0 auto;
        padding: 20px;
        border: 2px solid #ccc;
        border-radius: 8px;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        background-color: #f9f9f9;
    }
    .form-container label {
        display: block;
        margin-bottom: 8px;
    }
    .form-container input, .form-container select, .form-container button {
        width: 100%;
        padding: 10px;
        margin-bottom: 12px;
        border: 1px solid #ccc;
        border-radius: 4px;
    }
    .form-container button {
        background-color: #4CAF50;
        color: white;
        border: none;
        cursor: pointer;
    }
    .form-container button:hover {
        background-color: #45a049;
    }
</style>

<div class="form-container">
    <form method="POST">
        <label>Username</label>
        <input type="text" name="username" value="<?php echo $data['username']; ?>" required>
        <label>Password</label>
        <input type="text" name="password" value="<?php echo $data['password']; ?>" required>
        <label>Email</label>
        <input type="email" name="email" value="<?php echo $data['email']; ?>" required>
        <label>Nama Lengkap</label>
        <input type="text" name="nama_lengkap" value="<?php echo $data['nama_lengkap']; ?>" required>
        <label>Alamat</label>
        <input type="text" name="alamat" value="<?php echo $data['alamat']; ?>" required>
        <label>Level</label>
        <select name="level" required>
            <option value="admin" <?php if ($data['level'] == 'admin') echo 'selected'; ?>>Admin</option>
            <option value="petugas" <?php if ($data['level'] == 'petugas') echo 'selected'; ?>>Petugas</option>
        </select>
        <button type="submit">Simpan Perubahan</button>
        <a href="data_user.php" class="btn btn-secondary">Kembali</a>
    </form>
</div>

</body>
</html>
