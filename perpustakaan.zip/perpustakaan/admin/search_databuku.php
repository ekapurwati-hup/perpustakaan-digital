<?php
include 'koneksi.php';

$search = isset($_GET['search']) ? $conn->real_escape_string($_GET['search']) : '';
$sql = "SELECT * FROM buku WHERE judul LIKE '%$search%'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td>" . $row['bukuID'] . "</td>";
        echo "<td><img src='uploads/" . $row['gambar'] . "' width='50' alt='Gambar Buku'></td>";
        echo "<td>" . $row['judul'] . "</td>";
        echo "<td>" . $row['penulis'] . "</td>";
        echo "<td>" . $row['penerbit'] . "</td>";
        echo "<td>" . $row['tahunterbit'] . "</td>";
        echo "<td>" . $row['stok'] . "</td>";
        echo "</tr>";
    }
} else {
    echo "<tr><td colspan='7' class='text-center'>Tidak ada data buku</td></tr>";
}
?>
