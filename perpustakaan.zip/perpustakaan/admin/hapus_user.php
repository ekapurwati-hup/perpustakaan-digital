<?php
include 'koneksi.php';

if (isset($_GET['userID'])) {
    $userID = $_GET['userID'];

    // Query untuk menghapus data
    $sql = "DELETE FROM user WHERE userID = '$userID'";
    if (mysqli_query($conn, $sql)) {
        // Reindexing ID agar berurutan
        $reindexQuery = "
            SET @num = 0; 
            UPDATE user SET userID = (@num := @num + 1); 
            ALTER TABLE user AUTO_INCREMENT = 1;
        ";

        if (mysqli_multi_query($conn, $reindexQuery)) {
            echo "<script>
                    alert('Data berhasil dihapus dan ID telah diperbarui!');
                    window.location.href = 'admin_dataanggota.php';
                  </script>";
        } else {
            echo "<script>
                    alert('Data berhasil dihapus, tetapi gagal memperbarui ID!');
                    window.location.href = 'admin_dataanggota.php';
                  </script>";
        }
    } else {
        echo "<script>
                alert('Gagal menghapus data!');
                window.location.href = 'admin_dataanggota.php';
              </script>";
    }
} else {
    echo "<script>
            alert('Invalid Request');
            window.location.href = 'admin_dataanggota.php';
          </script>";
}

mysqli_close($conn);
?>
