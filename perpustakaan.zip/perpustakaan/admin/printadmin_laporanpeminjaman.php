<?php
session_start();
include 'koneksi.php';

// Ambil data peminjaman berdasarkan filter bulan dan tahun
$filterBulan = isset($_GET['bulan']) ? $_GET['bulan'] : '';
$filterTahun = isset($_GET['tahun']) ? $_GET['tahun'] : '';

$whereClause = '';
if ($filterBulan && $filterTahun) {
    $whereClause = "WHERE MONTH(peminjaman.tanggalpengembalian) = '$filterBulan' AND YEAR(peminjaman.tanggalpengembalian) = '$filterTahun'";
}

// Ambil data peminjaman
$sqlPeminjaman = "SELECT peminjaman.*, buku.judul, user.username 
                  FROM peminjaman 
                  JOIN buku ON peminjaman.bukuID = buku.bukuID
                  JOIN user ON peminjaman.userID = user.userID
                  $whereClause";
$resultPeminjaman = $conn->query($sqlPeminjaman);
// Mendapatkan tanggal cetak saat ini
$tanggalCetak = date('d F Y');

// Ambil username dari session
$username = isset($_SESSION['username']) ? $_SESSION['username'] : '';

// Ambil nama lengkap pengguna dari database
$sqlNamaLengkap = "SELECT nama_lengkap FROM user WHERE username = '$username'";
$resultNamaLengkap = $conn->query($sqlNamaLengkap);
$namaLengkap = '';

if ($resultNamaLengkap->num_rows > 0) {
    $row = $resultNamaLengkap->fetch_assoc();
    $namaLengkap = $row['nama_lengkap'];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cetak Laporan Data Peminjaman</title>
    <link href="../img/perpus.png" rel="shortcut icon" />
    <style>
        /* Styling untuk halaman cetak */
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }
        table, th, td {
            border: 1px solid black;
        }
        th, td {
            padding: 8px;
            text-align: left;
        }
        @media print {
            .no-print {
                display: none;
            }
        }
        h1 {
            text-align: center;
            line-height: 1.2;
        }
        .footer {
            margin-top: 40px;
            display: flex;
            justify-content: space-between;
            font-size: 14px;
        }
        .footer-left, .footer-right {
            width: 45%;
            margin-left: 30px;
        }

        .footer-right {
            margin-left: 100px;
            width: 45%;
            text-align: left;
            padding-left: 400px;
        }
    </style>
</head>
<body>

    <h1>
        LAPORAN<br>
        DATA PEMINJAMAN<br>
        APLIKASI PERPUSTAKAAN DIGITAL
    </h1>
    
    <table>
        <thead>
            <tr>
                <th>Nama</th>
                <th>Judul Buku</th>
                <th>Tanggal Peminjaman</th>
                <th>Tanggal Pengembalian</th>
                <th>Status</th>
            </tr>
        </thead>
        <tbody>
            <?php
            if ($resultPeminjaman->num_rows > 0) {
                while ($peminjaman = $resultPeminjaman->fetch_assoc()) {
                    echo "<tr>
                            <td>{$peminjaman['username']}</td>
                            <td>{$peminjaman['judul']}</td>
                            <td>{$peminjaman['tanggalpeminjaman']}</td>
                            <td>{$peminjaman['tanggalpengembalian']}</td>
                            <td>{$peminjaman['statuspeminjam']}</td>
                        </tr>";
                }
            } else {
                echo "<tr>
                        <td colspan='5' style='text-align: center;'>Tidak ada data pada bulan dan tahun yang dipilih</td>
                      </tr>";
            }
            ?>
        </tbody>
    </table>

    <!-- Footer -->
    <div class="footer">
        <div class="footer-right">
            <p>Jambi, <?php echo $tanggalCetak; ?></p>
            <p>Koordinator Perpustakaan</p>
            <br><br><br>
            <p><strong><?php echo $namaLengkap ? $namaLengkap : 'Nama Koordinator Perpustakaan'; ?></strong></p>

        </div>
    </div>

    <script>
        // Men-trigger print otomatis setelah halaman dimuat
        window.onload = function() {
            window.print();
            window.onafterprint = function() {
                window.close(); // Menutup tab setelah print
            }
        }
    </script>
</body>
</html>
