<?php
include 'koneksi.php';

// Periksa apakah userID dikirim melalui GET
if (isset($_GET['userID'])) {
    $userID = $_GET['userID'];

    // Ambil data user dengan level 'peminjam'
    $sql = "SELECT * FROM user WHERE userID = '$userID' AND level = 'peminjam'";
    $result = mysqli_query($conn, $sql);

    if (mysqli_num_rows($result) > 0) {
        $data = mysqli_fetch_assoc($result);
    } else {
        echo "<script>
                alert('Data peminjam tidak ditemukan!');
                window.location.href = 'data_user.php';
              </script>";
        exit;
    }
}

// Periksa apakah form telah disubmit
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];
    $email = $_POST['email'];
    $nama_lengkap = $_POST['nama_lengkap'];
    $alamat = $_POST['alamat'];

    // Enkripsi password
    $password_hashed = md5($password);

    // Update data user
    $sql = "UPDATE user SET 
                username = '$username', 
                password = '$password_hashed', 
                email = '$email', 
                nama_lengkap = '$nama_lengkap', 
                alamat = '$alamat' 
            WHERE userID = '$userID' AND level = 'peminjam'";

    if (mysqli_query($conn, $sql)) {
        echo "<script>
                alert('Data peminjam berhasil diperbarui!');
                window.location.href = 'admin_dataanggota.php';
              </script>";
    } else {
        echo "Error: " . mysqli_error($conn);
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Perpustakaan Digita</title>
    <link href="../img/perpus.png" rel="shortcut icon" />
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f9f9f9;
            margin: 0;
            padding: 20px;
        }
        .container {
            max-width: 600px;
            margin: 50px auto;
            background: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        h2 {
            text-align: center;
            margin-bottom: 20px;
            color: #333;
        }
        label {
            font-weight: bold;
            margin-top: 10px;
            display: block;
        }
        input[type="text"], input[type="email"] {
            width: 100%;
            padding: 10px;
            margin-top: 5px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
        button {
            background-color: #007BFF;
            color: #fff;
            border: none;
            padding: 10px 15px;
            border-radius: 5px;
            cursor: pointer;
            width: 100%;
        }
        button:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Edit Data Peminjam</h2>
        <form method="POST">
            <label>Username</label>
            <input type="text" name="username" value="<?php echo htmlspecialchars($data['username']); ?>" required>

            <label>Password</label>
            <input type="text" name="password" value="<?php echo htmlspecialchars($data['password']); ?>" required>

            <label>Email</label>
            <input type="email" name="email" value="<?php echo htmlspecialchars($data['email']); ?>" required>

            <label>Nama Lengkap</label>
            <input type="text" name="nama_lengkap" value="<?php echo htmlspecialchars($data['nama_lengkap']); ?>" required>

            <label>Alamat</label>
            <input type="text" name="alamat" value="<?php echo htmlspecialchars($data['alamat']); ?>" required>

            <button type="submit">Simpan Perubahan</button>
        </form>
    </div>
</body>
</html>
