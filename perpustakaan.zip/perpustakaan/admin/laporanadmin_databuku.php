<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>Perpustakaan Digita</title>
    <link href="../img/perpus.png" rel="shortcut icon" />
    <link href="https://cdn.jsdelivr.net/npm/simple-datatables@7.1.2/dist/style.min.css" rel="stylesheet" />
    <link href="css/styles.css" rel="stylesheet" />
    <script src="https://use.fontawesome.com/releases/v6.3.0/js/all.js" crossorigin="anonymous"></script>
</head>
<body class="sb-nav-fixed">
        <nav class="sb-topnav navbar navbar-expand navbar-dark bg-dark">
            <!-- Navbar Brand-->
            <a class="navbar-brand ps-3" href="index.html">Perpustakaan Digital</a>
            <!-- Sidebar Toggle-->
            <button class="btn btn-link btn-sm order-1 order-lg-0 me-4 me-lg-0" id="sidebarToggle" href="#!"><i class="fas fa-bars"></i></button>
            <!-- Navbar Search-->
            <form class="d-none d-md-inline-block form-inline ms-auto me-0 me-md-3 my-2 my-md-0">
                <div class="input-group">
                    
                </div>
            </form>
            <!-- Navbar-->
            <ul class="navbar-nav ms-auto ms-md-0 me-3 me-lg-4">
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" id="navbarDropdown" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false"><i class="fas fa-user fa-fw"></i></a>
                    <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                        
                        <li><hr class="dropdown-divider" /></li>
                        <li><a class="dropdown-item" href="../login.php">Logout</a></li>
                    </ul>
                </li>
            </ul>
        </nav>
    <div id="layoutSidenav">
        <div id="layoutSidenav_nav">
            <nav class="sb-sidenav accordion sb-sidenav-dark" id="sidenavAccordion">
                <div class="sb-sidenav-menu">
                    <div class="nav">
                        <div class="sb-sidenav-menu-heading">Core</div>
                        <a class="nav-link" href="admin.php">
                            <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                            Dashboard
                        </a>
                        <div class="sb-sidenav-menu-heading">Navigasi</div>
                        <a class="nav-link" href="data_user.php">
                            <div class="sb-nav-link-icon"><i class="fas fa-table"></i></div>
                            Data User
                        </a>
                        <a class="nav-link" href="admin_dataanggota.php">
                                <div class="sb-nav-link-icon"><i class="fas fa-table"></i></div>
                                Data Anggota
                            </a>
                        <a class="nav-link" href="data_bukuadmin.php">
                            <div class="sb-nav-link-icon"><i class="fas fa-book"></i></div>
                            Data Buku
                        </a>
                        <a class="nav-link" href="data_peminjamadmin.php">
                                <div class="sb-nav-link-icon"><i class="fas fa-book"></i></div>
                                peminjaman
                            </a>
                            <a class="nav-link collapsed" href="#" data-bs-toggle="collapse" data-bs-target="#collapseLaporan" aria-expanded="false" aria-controls="collapseLaporan">
                                <div class="sb-nav-link-icon"><i class="fas fa-book-open"></i></div>
                                Laporan
                                <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                            </a>
                            <div class="collapse" id="collapseLaporan" aria-labelledby="headingOne" data-bs-parent="#sidenavAccordion">
                                <nav class="sb-sidenav-menu-nested nav">
                                    <a class="nav-link" href="laporanadmin_datapeminjam.php">Laporan Data Pinjam</a>
                                    <a class="nav-link" href="laporanadmin_databuku.php">Laporan Data Buku</a>
                                    <a class="nav-link" href="laporanadmin_dataanggota.php">Laporan Data Anggota</a>
                                </nav>
                            </div>
                        <a class="nav-link" href="../login.php">
                            <div class="sb-nav-link-icon"><i class="fa fa-power-off"></i></div>
                            Logout
                        </a>
                    </div>
                </div>
                
            </nav>
        </div>
        <div id="layoutSidenav_content">
            <main>
                <div class="container-fluid px-4">
                    <h1 class="mt-4">Perpustakaan Digital</h1>
                    <ol class="breadcrumb mb-4">
                        <li class="breadcrumb-item active">Dashboard</li>
                    </ol>
                    <div class="card mb-4">
                    <div class="card-header d-flex justify-content-between align-items-center">
    <div>
        <i class="fas fa-table me-1"></i>
        Data Buku
    </div>
    <div>
        <!-- Form Pencarian -->
        <form method="GET" action="laporanadmin_databuku.php" class="d-flex">
        <input type="text" id="searchInput" placeholder="Cari Nama buku" class="form-control" >
            <a href="printadmin_laporanbuku.php?search=<?php echo isset($_GET['search']) ? $_GET['search'] : ''; ?>" target="_blank" class="btn btn-success ms-2">Cetak</a>

        </form>
        <form>            
        </form>
    </div>
</div>


    <div class="card-body">
        <table class="table table-bordered" id="bukutabel" width="100%" cellspacing="0">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Gambar</th>
                    <th>Judul</th>
                    <th>Penulis</th>
                    <th>Penerbit</th>
                    <th>Tahun Terbit</th>
                    <th>Stok</th>
                </tr>
            </thead>
            <tbody>
<?php
include 'koneksi.php';

$search = isset($_GET['search']) ? $conn->real_escape_string($_GET['search']) : '';
$sql = "SELECT * FROM buku";
if ($search) {
    $sql .= " WHERE judul LIKE '%$search%'";
}
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td>" . $row['bukuID'] . "</td>";
        echo "<td><img src='uploads/" . $row['gambar'] . "' width='50' alt='Gambar Buku'></td>";
        echo "<td>" . $row['judul'] . "</td>";
        echo "<td>" . $row['penulis'] . "</td>";
        echo "<td>" . $row['penerbit'] . "</td>";
        echo "<td>" . $row['tahunterbit'] . "</td>";
        echo "<td>" . $row['stok'] . "</td>";
        echo "</tr>";
    }
} else {
    echo "<tr><td colspan='7' class='text-center'>Tidak ada data buku</td></tr>";
}
?>
            </tbody>
        </table>
    </div>
</div>


                </div>
            </main>
            <footer class="py-4 bg-light mt-auto">
                <div class="container-fluid px-4">
                    <div class="d-flex align-items-center justify-content-between small">
                        <div class="text-muted">Copyright &copy; Your Website 2025</div>
                        <div>
                            
                        </div>
                    </div>
                </div>
            </footer>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
    <script src="js/scripts.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.8.0/Chart.min.js" crossorigin="anonymous"></script>
    <script src="assets/demo/chart-area-demo.js"></script>
    <script src="assets/demo/chart-bar-demo.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/simple-datatables@7.1.2/dist/umd/simple-datatables.min.js" crossorigin="anonymous"></script>
    <script src="js/datatables-simple-demo.js"></script>
    <script>
    // JavaScript untuk fungsi pencarian berdasarkan Nama buku dan No buku
    document.getElementById("searchInput").addEventListener("keyup", function() {
        let input = document.getElementById("searchInput").value.toLowerCase();
        let table = document.getElementById("bukutabel");
        let tr = table.getElementsByTagName("tr");

        // Loop melalui semua baris tabel, kecuali header
        for (let i = 1; i < tr.length; i++) {
          let namaTd = tr[i].getElementsByTagName("td")[1]; // Kolom Nama buku
          let indeksTd = tr[i].getElementsByTagName("td")[2]; // Kolom No buku
          if (namaTd || indeksTd) {
            let namaText = namaTd ? namaTd.textContent || namaTd.innerText : "";
            let indeksText = indeksTd ? indeksTd.textContent || indeksTd.innerText : "";
            tr[i].style.display = namaText.toLowerCase().includes(input) || indeksText.toLowerCase().includes(input) ? "" : "none";
          }
        }
    });
    
  </script>
</body>
</html>
