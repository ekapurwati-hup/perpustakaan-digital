<?php
include 'koneksi.php'; // File koneksi ke database

if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // Ambil data buku untuk menghapus file gambar (jika ada)
    $query = "SELECT gambar FROM buku WHERE bukuID = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $gambar = $row['gambar'];

        // Hapus file gambar jika ada
        if (!empty($gambar) && file_exists("uploads/" . $gambar)) {
            unlink("uploads/" . $gambar); // Menghapus file gambar
        }

        // Hapus data dari tabel
        $deleteQuery = "DELETE FROM buku WHERE bukuID = ?";
        $deleteStmt = $conn->prepare($deleteQuery);
        $deleteStmt->bind_param("i", $id);

        if ($deleteStmt->execute()) {
            // Perbarui ulang urutan bukuID agar berurutan
            $reorderQuery = "SET @new_id = 0;
                             UPDATE buku SET bukuID = (@new_id := @new_id + 1);
                             ALTER TABLE buku AUTO_INCREMENT = 1;";
            if ($conn->multi_query($reorderQuery)) {
                // Redirect ke halaman data_bukuadmin.php dengan pesan sukses
                header("Location: data_bukuadmin.php?message=success");
                exit();
            } else {
                // Redirect ke halaman data_bukuadmin.php dengan pesan error
                header("Location: data_bukuadmin.php?message=error_reorder");
                exit();
            }
        } else {
            // Redirect ke halaman data_bukuadmin.php dengan pesan error
            header("Location: data_bukuadmin.php?message=error");
            exit();
        }
    } else {
        // Redirect jika buku tidak ditemukan
        header("Location: data_bukuadmin.php?message=not_found");
        exit();
    }
} else {
    // Redirect jika parameter ID tidak ditemukan
    header("Location: data_bukuadmin.php?message=missing_id");
    exit();
}
?>
