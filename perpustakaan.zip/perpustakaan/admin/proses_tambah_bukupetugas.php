<?php
include 'koneksi.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $judul = $_POST['judul'];
    $penulis = $_POST['penulis'];
    $penerbit = $_POST['penerbit'];
    $tahunterbit = $_POST['tahunterbit'];
    $stok = $_POST['stok'];
    $keterangan = $_POST['keterangan']; // Ambil data dari input keterangan
    $gambar = $_FILES['gambar']['name'];

    $target_dir = "uploads/";
    $target_file = $target_dir . basename($gambar);

    // Proses upload file gambar
    if (move_uploaded_file($_FILES['gambar']['tmp_name'], $target_file)) {
        // Tambahkan keterangan ke dalam query SQL
        $sql = "INSERT INTO buku (gambar, judul, penulis, penerbit, tahunterbit, stok, keterangan) 
                VALUES ('$gambar', '$judul', '$penulis', '$penerbit', '$tahunterbit', '$stok', '$keterangan')";

        if ($conn->query($sql) === TRUE) {
            echo "<script>
                alert('Data buku berhasil ditambahkan!');
                window.location.href = 'tambah_bukupetugas.php';
              </script>";
            
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }
    } else {
        echo "Gagal mengupload gambar.";
    }
}
?>
