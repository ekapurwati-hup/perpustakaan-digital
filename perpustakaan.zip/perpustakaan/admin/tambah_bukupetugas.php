<?php
include 'koneksi.php'; // File koneksi database
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Perpustakaan Digita</title>
    <link href="../img/perpus.png" rel="shortcut icon" />

    <!-- Add styling for the form box -->
<style>
    .form-container {
        width: 50%;
        margin: 0 auto;
        padding: 20px;
        border: 2px solid #ccc;
        border-radius: 8px;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        background-color: #f9f9f9;
    }
    .form-container label {
        display: block;
        margin-bottom: 8px;
    }
    .form-container input, .form-container select, .form-container button {
        width: 100%;
        padding: 10px;
        margin-bottom: 12px;
        border: 1px solid #ccc;
        border-radius: 4px;
    }
    .form-container button {
        background-color: #4CAF50;
        color: white;
        border: none;
        cursor: pointer;
    }
    .form-container button:hover {
        background-color: #45a049;
    }
</style>

</head>
<body>
<div class="form-container">
        <h2>Tambah Data Buku</h2>
        <form action="proses_tambah_bukupetugas.php" method="POST" enctype="multipart/form-data">
            <label for="judul">Judul Buku:</label>
            <input type="text" id="judul" name="judul" required>

            <label for="penulis">Penulis:</label>
            <input type="text" id="penulis" name="penulis" required>

            <label for="penerbit">Penerbit:</label>
            <input type="text" id="penerbit" name="penerbit" required>

            <label for="tahunterbit">Tahun Terbit:</label>
            <input type="number" id="tahunterbit" name="tahunterbit" min="1900" max="2099" required>

            <label for="stok">Stok:</label>
            <input type="number" id="stok" name="stok" required>

            <label for="gambar">Upload Gambar:</label>
            <input type="file" id="gambar" name="gambar" accept="image/*" required>

            <label for="keterangan">Keterangan Buku:</label>
            <textarea id="keterangan" name="keterangan" rows="4" placeholder="Masukkan keterangan buku..." required></textarea>

            <button type="submit">Tambah Buku</button>
            <a href="data_bukupetugas.php">Kembali</a>
        </form>
    </div>
</body>
</html>
