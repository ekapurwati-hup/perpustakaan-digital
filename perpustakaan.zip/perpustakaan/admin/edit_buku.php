<?php
// Panggil koneksi
include 'koneksi.php';

// Cek apakah parameter 'id' ada di URL
if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // Ambil data buku berdasarkan ID
    $query = "SELECT * FROM buku WHERE bukuID = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param('i', $id);
    $stmt->execute();
    $result = $stmt->get_result();

    // Periksa apakah data ditemukan
    if ($result->num_rows > 0) {
        $buku = $result->fetch_assoc();
    } else {
        echo "Buku tidak ditemukan.";
        exit;
    }
} else {
    echo "ID buku tidak diberikan.";
    exit;
}

// Jika formulir disubmit
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $judul = $_POST['judul'];
    $penulis = $_POST['penulis'];
    $penerbit = $_POST['penerbit'];
    $tahun_terbit = $_POST['tahun_terbit'];
    $stok = $_POST['stok'];
    $keterangan = $_POST['keterangan'];
    $gambar_lama = $buku['gambar']; // Gambar lama

    // Periksa apakah ada file gambar baru yang diunggah
    if (!empty($_FILES['gambar']['name'])) {
        $gambar_baru = $_FILES['gambar']['name'];
        $tmp_name = $_FILES['gambar']['tmp_name'];
        $target_dir = "uploads/"; // Direktori penyimpanan gambar
        $target_file = $target_dir . basename($gambar_baru);

        // Pindahkan file ke direktori target
        if (move_uploaded_file($tmp_name, $target_file)) {
            // Hapus gambar lama jika ada
            if (!empty($gambar_lama) && file_exists($target_dir . $gambar_lama)) {
                unlink($target_dir . $gambar_lama);
            }
        } else {
            echo "Gagal mengunggah gambar.";
            exit;
        }
    } else {
        $gambar_baru = $gambar_lama; // Gunakan gambar lama jika tidak ada yang baru
    }

    // Update data buku
    $update_query = "UPDATE buku SET judul = ?, penulis = ?, penerbit = ?, tahunterbit = ?, stok = ?, keterangan = ?, gambar = ? WHERE bukuID = ?";
    $update_stmt = $conn->prepare($update_query);
    $update_stmt->bind_param('sssisssi', $judul, $penulis, $penerbit, $tahun_terbit, $stok, $keterangan, $gambar_baru, $id);

    if ($update_stmt->execute()) {
        echo "<script>alert('Data buku berhasil diperbarui.'); window.location.href='data_bukuadmin.php';</script>";
    } else {
        echo "Error: " . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Perpustakaan Digita</title>
    <link href="../img/perpus.png" rel="shortcut icon" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body>
<div class="container mt-5">
    <h2>Edit Buku</h2>
    <form method="POST" enctype="multipart/form-data">
        <div class="mb-3">
            <label for="judul" class="form-label">Judul Buku</label>
            <input type="text" class="form-control" id="judul" name="judul" value="<?= htmlspecialchars($buku['judul']) ?>" required>
        </div>
        <div class="mb-3">
            <label for="penulis" class="form-label">Penulis</label>
            <input type="text" class="form-control" id="penulis" name="penulis" value="<?= htmlspecialchars($buku['penulis']) ?>" required>
        </div>
        <div class="mb-3">
            <label for="penerbit" class="form-label">Penerbit</label>
            <input type="text" class="form-control" id="penerbit" name="penerbit" value="<?= htmlspecialchars($buku['penerbit']) ?>" required>
        </div>
        <div class="mb-3">
            <label for="tahun_terbit" class="form-label">Tahun Terbit</label>
            <input type="number" class="form-control" id="tahun_terbit" name="tahun_terbit" value="<?= htmlspecialchars($buku['tahunterbit']) ?>" required>
        </div>
        <div class="mb-3">
            <label for="stok" class="form-label">Stok</label>
            <input type="number" class="form-control" id="stok" name="stok" value="<?= htmlspecialchars($buku['stok']) ?>" required>
        </div>
        <div class="mb-3">
            <label for="keterangan" class="form-label">Keterangan</label>
            <textarea class="form-control" id="keterangan" name="keterangan"><?= htmlspecialchars($buku['keterangan']) ?></textarea>
        </div>
        <div class="mb-3">
            <label for="gambar" class="form-label">Gambar Buku</label>
            <input type="file" class="form-control" id="gambar" name="gambar">
            <?php if (!empty($buku['gambar'])): ?>
                <p>Gambar saat ini: <img src="uploads/<?= htmlspecialchars($buku['gambar']) ?>" alt="Gambar Buku" width="100"></p>
            <?php endif; ?>
        </div>
        <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
        <a href="data_bukuadmin.php" class="btn btn-secondary">Kembali</a>
    </form>
</div>
</body>
</html>
