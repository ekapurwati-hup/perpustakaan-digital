<?php
include 'koneksi.php'; // Pastikan file koneksi sudah ada

// Ambil parameter pencarian
$search = isset($_GET['search']) ? $_GET['search'] : '';
$searchQuery = $search ? "AND nama_lengkap LIKE '%" . mysqli_real_escape_string($conn, $search) . "%'" : '';

// Query untuk mengambil data
$sql = "SELECT * FROM user WHERE level IN ('peminjam') $searchQuery";
$result = mysqli_query($conn, $sql);

// Mendapatkan tanggal cetak saat ini
$tanggalCetak = date('d F Y');

session_start();
// Ambil username dari session
$username = isset($_SESSION['username']) ? $_SESSION['username'] : '';

// Ambil nama lengkap pengguna dari database
$sqlNamaLengkap = "SELECT nama_lengkap FROM user WHERE username = '$username'";
$resultNamaLengkap = $conn->query($sqlNamaLengkap);
$namaLengkap = '';

if ($resultNamaLengkap->num_rows > 0) {
    $row = $resultNamaLengkap->fetch_assoc();
    $namaLengkap = $row['nama_lengkap'];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cetak Data Anggota</title>
    <link href="../img/perpus.png" rel="shortcut icon" />
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        table, th, td {
            border: 1px solid black;
        }
        th, td {
            padding: 8px;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
        }
        h1 {
            text-align: center;
            line-height: 1.2;
        }
        .footer {
            margin-top: 40px;
            display: flex;
            justify-content: space-between;
            font-size: 14px;
        }
        .footer-left, .footer-right{
            width: 45%;
            margin-left:30px; /* Menggeser elemen ke kanan */
        }

        .footer-right {
    margin-left:100px; /* Menggeser elemen ke kanan */
    width: 45%; /* Menentukan lebar elemen */
    text-align: left; /* Membuat teks di dalam elemen rata kiri */
    padding-left: 400px; /* Pastikan padding kiri diatur sesuai kebutuhan */
}
    </style>
</head>
<body>
<h1>
        LAPORAN<br>
        DATA ANGGOTA<br>
        APLIKASI PERPUSTAKAAN DIGITAL
    </h1>
    <table>
        <thead>
            <tr>
                <th>No</th>
                <th>Nama</th>
                <th>Email</th>
                <th>Nama Lengkap</th>
                <th>Alamat</th>
                <th>Level</th>
            </tr>
        </thead>
        <tbody>
            <?php
            if (mysqli_num_rows($result) > 0) {
                while ($row = mysqli_fetch_assoc($result)) {
                    echo "<tr>";
                    echo "<td>" . $row['userID'] . "</td>";
                    echo "<td>" . $row['username'] . "</td>";
                    echo "<td>" . $row['email'] . "</td>";
                    echo "<td>" . $row['nama_lengkap'] . "</td>";
                    echo "<td>" . $row['alamat'] . "</td>";
                    echo "<td>" . $row['level'] . "</td>";
                    echo "</tr>";
                }
            } else {
                echo "<tr><td colspan='7' style='text-align:center;'>Tidak ada data</td></tr>";
            }
            mysqli_close($conn);
            ?>
        </tbody>
    </table>

    <!-- Footer with Kepala Sekolah info and Koordinator Perpustakaan -->
    <div class="footer">
        
        <div class="footer-right">
            <p>Jambi, <?php echo $tanggalCetak; ?></p>
            <p>Koordinator Perpustakaan</p>
            <br>
            <br>
            <br>
            <p><strong><?php echo $namaLengkap ? $namaLengkap : 'Nama Koordinator Perpustakaan'; ?></strong></p>
        </div>
    </div>

    <script>
        // Men-trigger print otomatis setelah halaman dimuat
        window.onload = function() {
            window.print();
            window.onafterprint = function() {
                window.close(); // Menutup tab setelah print
            }
        }
    </script>
</body>
</html>
