<?php
session_start();
include 'koneksi.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Query untuk memeriksa login
    $sql = "SELECT * FROM user WHERE username = ? AND password = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ss", $username, $password);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $_SESSION['userID'] = $row['userID'];
        $_SESSION['username'] = $row['username'];
        $_SESSION['level'] = $row['level'];
        

        // Arahkan pengguna ke folder dan file yang sesuai dengan level
        if ($row['level'] == 'admin') {
            header("Location: admin/admin.php");
            exit;
        } elseif ($row['level'] == 'petugas') {
            header("Location: admin/petugas.php");
            exit;
        } elseif ($row['level'] == 'peminjam') {
            header("Location: peminjam/peminjam.php");
            exit;
        }
        
    } else {
        echo "<script>alert('Username atau Password salah');</script>";
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Halaman Login</title>
    <link href="../img/perpus.png" rel="shortcut icon" />
    <style>
        body {
            font-family: Arial, sans-serif;
            /*background: linear-gradient(to right,rgb(2, 46, 84),rgb(3, 83, 87));*/
            background-image: url('gambar.png');
            background-size: 100%;
            color: #333;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        .login-container {
            background: #fff;
            padding: 20px 30px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
            width: 100%;
            max-width: 400px;
            text-align: center;
        }
        .login-container h2 {
            margin-bottom: 20px;
            color:rgb(20, 21, 22);
        }
        .login-container input {
            width: 100%;
            padding: 10px;
            margin: 10px 0;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 16px;
        }
        .login-container button {
            width: 100%;
            padding: 10px;
            background:rgb(22, 30, 37);
            color: #fff;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            cursor: pointer;
            transition: background 0.3s;
        }
        .login-container button:hover {
            background:rgb(24, 43, 49);
        }
        .login-container p {
            margin-top: 15px;
        }
        .login-container a {
            color:rgb(29, 37, 44);
            text-decoration: none;
        }
        .login-container a:hover {
            text-decoration: underline;
        }

        .welcome-box {
            background: #eef;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
            margin-bottom: 20px;
            color: rgb(12, 52, 87);
            font-size: 18px;
            font-weight: bold;
        }
    </style>
</head>
<body>
<div class="container">
        
    <div class="login-container">
    <div class="welcome-box">
            <br>SELAMAT DATANG</br>
            <br>DI APLIKASI PERPUSTAKAAN DIGITAL</br>
        </div>
        <h2>Login Di Sini</h2>
        <form action="" method="POST">
            <input type="text" name="username" placeholder="Username" required>
            <input type="password" name="password" placeholder="Password" required>
            <button type="submit">Login</button>
        </form>
        <p>Belum punya akun? <a href="register.php">Daftar di sini</a></p>
    </div>
</body>
</html>

